//
//  ViewController.swift
//  homework03_calculator
// 110aem001 盧佩怡 二資港生一
//  Created by lo pui yi on 21/3/2022.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lblEqution: UILabel!
    @IBOutlet weak var lblresult: UILabel!
    

    @IBOutlet weak var btnClear: UIButton!
    
    @IBOutlet var btnNum: [UIButton]!
    
    @IBOutlet var btnOperator: [UIButton]!
    @IBOutlet var btnOperatorPlus: [UIButton]!
    
    
    var negSign:Bool=false;
    var tempNum:String="0"{
        didSet{
            print("tempNum:\(tempNum)")
        }
    }
    var nums = ["1","2","3","4","5","6","7","8","9","0"]

    
    var equtionString:String="0"{
        didSet{
        
                lblEqution.text=equtionString;
            print("equtionString:\(equtionString)")
        }
    }
    
    var resultString:String = "0"{
        didSet{
            lblresult.text = resultString
            
        }
    }
    
    var calString:String=""{
        didSet{
            print("calString:\(calString)")
        }
    }
    
    
    @IBAction func enterNumber(_ sender: UIButton) {
        
        
       
        // all clear after enter 1st "="
        if equtionString.last == "=" {
            allClear()
        }
        
        btnClear.setTitle("C", for: .normal)
        
        for btn in btnOperator{
            btn.backgroundColor=#colorLiteral(red: 1, green: 0.5857489705, blue: 0.0139905503, alpha: 1)
            btn.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        }
        
        if let num = btnNum.firstIndex(of: sender){
            
            if sender.currentTitle == String(nums[num]){
                
               if(equtionString=="0"){
                    equtionString = nums[num]
                } else{
                    equtionString += nums[num]
                }
                
                if(tempNum.first=="0" && !tempNum.contains("0.")){
                    tempNum = nums[num]
                }else{
                    tempNum += nums[num]
                }
                
                
            }
            
        }
    }
    
    
    
    @IBAction func enterOpeartor(_ sender: UIButton) {
        
        //set default operator button color
        for btn in btnOperator{
            btn.backgroundColor=#colorLiteral(red: 1, green: 0.5857489705, blue: 0.0139905503, alpha: 1)
            btn.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        }
        
        // continus calculate after enter 1st "="
        if equtionString.last == "=" {
            equtionString=resultString
            calString=""
            tempNum = resultString
        }
        
        
        switch sender.currentTitle{
        
        case "+":
            //highlight
            sender.backgroundColor=#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            sender.setTitleColor(#colorLiteral(red: 1, green: 0.5857489705, blue: 0.0139905503, alpha: 1), for: .normal)
            
            checkOperator(cur_operator: "+")

            tempNum = "0"
            break
        case "-":
            sender.backgroundColor=#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            sender.setTitleColor(#colorLiteral(red: 1, green: 0.5857489705, blue: 0.0139905503, alpha: 1), for: .normal)
            checkOperator(cur_operator:"-")
            tempNum = "0"
            break
        case "×":
            sender.backgroundColor=#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            sender.setTitleColor(#colorLiteral(red: 1, green: 0.5857489705, blue: 0.0139905503, alpha: 1), for: .normal)
            checkOperator(cur_operator:"*")
            tempNum = "0"
            break
        case "÷":
            sender.backgroundColor=#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            sender.setTitleColor(#colorLiteral(red: 1, green: 0.5857489705, blue: 0.0139905503, alpha: 1), for: .normal)
            checkOperator(cur_operator:"/")
            tempNum = "0"
            break
            
        case "=":
            equtionString += "="
            calString += "\(String(describing: tempNum))"
            
            
            //if contains ÷0,display 0
            if(equtionString.contains("÷0")){
                resultString="0"
            }else{
                //calculate calString
                 let expression = NSExpression(format: calString)
                 let doubleResult = expression.expressionValue(with: nil, context: nil) as! Double
                 
                 resultString = forTrailingZero(temp:doubleResult)
            
            }

           
        
            break
        
            
        default:
            break
            
        }
        
    }
    
    
    @IBAction func enterOperatorPlus(_ sender: UIButton) {
        
      
        
        
        switch sender.currentTitle{
        case "C": //only clear number
            let numberSet = CharacterSet.init(charactersIn: "1234567890.")
            let operatorSet = CharacterSet.init(charactersIn: "+-x÷%")
            
            var lastEquStr=String(equtionString.last!)
            if let lastValue = lastEquStr.rangeOfCharacter(from: numberSet)
                {//last equation string is number, clear last number
                if(equtionString.count == 1){
                    equtionString = "0"
                }else{
                    equtionString.removeLast()
                }
                
                if(tempNum.count == 1){
                    tempNum = "0"
                }else{
                    tempNum.removeLast()
                }
                
                // after remove,if last equation string is operator,higtlight the opeator and change to AC
                if(equtionString.count >= 1){ lastEquStr=String(equtionString.last!)
                    if let lastValueAfter = lastEquStr.rangeOfCharacter(from: operatorSet){
                        for btn in btnOperator{
                            if(btn.currentTitle == lastEquStr ){
                                btn.backgroundColor=#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                                btn.setTitleColor(#colorLiteral(red: 1, green: 0.5857489705, blue: 0.0139905503, alpha: 1), for: .normal)
                            }
                        }
                        
                        sender.setTitle("AC", for: .normal)
                        
                    }
                    
                }
               

            }else{ //if last equation string is operator
            
                if(equtionString.last == "=" ){
                    allClear()
                    sender.setTitle("C", for: .normal)
                }else{
                    for btn in btnOperator{
                        if(btn.currentTitle == lastEquStr ){
                            btn.backgroundColor=#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                            btn.setTitleColor(#colorLiteral(red: 1, green: 0.5857489705, blue: 0.0139905503, alpha: 1), for: .normal)
                        }
                    }
                    sender.setTitle("AC", for: .normal)
                }
                
                
                
            }
            
            break
            
        case "AC": //all clear
            allClear()
            sender.setTitle("C", for: .normal)
            break
            
            
        case ".":
            // all clear and set "0." after enter 1st "="
            if equtionString.last == "=" {
                allClear()
            }
            
            //only one "."
            if !tempNum.contains(".") {
                equtionString += "."
                tempNum+="."
            }
            
            
            break
            
        case "%":
            // %the result after enter 1st "="
            if equtionString.last == "=" {
                calString=""
                equtionString=resultString
            }
            
            equtionString += "%"
            tempNum = String(Double(tempNum)!/100)
            break
            
        case "+/-":
            // all clear  after enter 1st "="
            if equtionString.last == "=" {
                allClear()
            }
            
            negSign = !negSign
            if(negSign){
                if(equtionString == "0"||equtionString==""){  //only press - in first
                    equtionString="-"
                }else{  //press number then press -
                    
                    equtionString.insert("-", at: equtionString.index(equtionString.startIndex, offsetBy: equtionString.count-tempNum.count))
                }
                tempNum.insert("-", at:tempNum.startIndex)
                
            }else{
                if(tempNum.first == "-"){
                    tempNum.remove(at: tempNum.startIndex)
                    if (equtionString=="-"){
                        equtionString=""
                    }else{
                        equtionString.remove(at: equtionString.index(equtionString.startIndex, offsetBy: equtionString.count-tempNum.count-1))
                        
                    }
                    
                    
                   
                }
                
                
            }
                
            break
        default:
            break
            
        }
    }
    
    //check last character of equtionString is num or operator
    func checkOperator(cur_operator:String){
        let operatorSet = CharacterSet.init(charactersIn: "+-x÷")
        
        var show_operator = cur_operator
        if show_operator == "/" {
            show_operator = "÷"
    }else if show_operator == "*"{
        show_operator = "x"
        }
        
        let lastEquStr=String(equtionString.last!)
        if let lastValue = lastEquStr.rangeOfCharacter(from: operatorSet)
            {//last equation string is operator
            equtionString.removeLast()
            equtionString += "\(show_operator)"
            calString.removeLast()
            calString += "\(cur_operator)"
            
            
        }else{//last equation string is number
            equtionString += "\(show_operator)"
            calString += "\(Double(tempNum)!)\(cur_operator)"
        }
    }
    
    func forTrailingZero(temp: Double) -> String {
        let formatter = NumberFormatter()
           formatter.minimumFractionDigits = 0
           formatter.maximumFractionDigits = 8
        let tempVar = formatter.string(from: NSNumber(value: temp))!
        return tempVar
    }
    

    
    func allClear(){
        
        resultString = "0"
        calString = ""
        tempNum="0"
        negSign = false
        for btn in btnOperator{
            btn.backgroundColor=#colorLiteral(red: 1, green: 0.5857489705, blue: 0.0139905503, alpha: 1)
            btn.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        }
        equtionString = "0"
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

}



